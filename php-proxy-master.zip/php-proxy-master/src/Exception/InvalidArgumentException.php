<?php

namespace Proxy\Exception;

class InvalidArgumentException extends \InvalidArgumentException
{
}
