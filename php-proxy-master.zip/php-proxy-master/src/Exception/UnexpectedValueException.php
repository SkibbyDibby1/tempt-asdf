<?php

namespace Proxy\Exception;

class UnexpectedValueException extends \UnexpectedValueException
{
}
